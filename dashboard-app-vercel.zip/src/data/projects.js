
const projects = [
  { name: "Süreç Haritası 1", type: "Haritalama", status: "Devam Eden", completion: "60%" },
  { name: "Process Mining 1", type: "Process Mining", status: "Planlanan", completion: "0%" },
  { name: "İyileştirme 1", type: "İyileştirme", status: "Biten", completion: "100%" },
  { name: "Süreç Haritası 2", type: "Haritalama", status: "Biten", completion: "100%" },
  { name: "İyileştirme 2", type: "İyileştirme", status: "Devam Eden", completion: "45%" }
];

export default projects;
