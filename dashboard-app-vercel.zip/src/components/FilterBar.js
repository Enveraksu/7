
import React from "react";

function FilterBar({ filters, setFilters }) {
  return (
    <div className="flex gap-4 mb-6">
      <select
        value={filters.year}
        onChange={(e) => setFilters({ ...filters, year: e.target.value })}
        className="border p-2 rounded"
      >
        <option>2025</option>
        <option>2024</option>
      </select>
      <select
        value={filters.type}
        onChange={(e) => setFilters({ ...filters, type: e.target.value })}
        className="border p-2 rounded"
      >
        <option>All</option>
        <option>Haritalama</option>
        <option>Process Mining</option>
        <option>İyileştirme</option>
      </select>
      <select
        value={filters.status}
        onChange={(e) => setFilters({ ...filters, status: e.target.value })}
        className="border p-2 rounded"
      >
        <option>All</option>
        <option>Biten</option>
        <option>Devam Eden</option>
        <option>Planlanan</option>
      </select>
    </div>
  );
}

export default FilterBar;
