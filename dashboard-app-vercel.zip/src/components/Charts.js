
import React from "react";
import { PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";

const COLORS = ["#4CAF50", "#FF9800", "#2196F3"];

function Charts({ projects }) {
  const data = [
    { name: "Biten", value: projects.filter(p => p.status === "Biten").length },
    { name: "Devam Eden", value: projects.filter(p => p.status === "Devam Eden").length },
    { name: "Planlanan", value: projects.filter(p => p.status === "Planlanan").length }
  ];

  return (
    <div className="grid grid-cols-2 gap-6 mb-6">
      <div className="bg-white p-4 shadow rounded-xl">
        <h3 className="font-bold mb-4">Proje Durum Dağılımı</h3>
        <PieChart width={300} height={300}>
          <Pie data={data} dataKey="value" nameKey="name" outerRadius={100} label>
            {data.map((entry, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </div>
      <div className="bg-white p-4 shadow rounded-xl">
        <h3 className="font-bold mb-4">Proje Türü Bazlı Dağılım</h3>
        <BarChart width={400} height={300} data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="value" fill="#8884d8" />
        </BarChart>
      </div>
    </div>
  );
}

export default Charts;
