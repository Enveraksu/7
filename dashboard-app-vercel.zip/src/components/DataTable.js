
import React from "react";

function DataTable({ projects }) {
  return (
    <div className="bg-white p-4 shadow rounded-xl">
      <h3 className="font-bold mb-4">Proje Listesi</h3>
      <table className="w-full text-left border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">Proje Adı</th>
            <th className="p-2">Tür</th>
            <th className="p-2">Durum</th>
            <th className="p-2">Tamamlanma %</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((proj, i) => (
            <tr key={i} className="border-t">
              <td className="p-2">{proj.name}</td>
              <td className="p-2">{proj.type}</td>
              <td className="p-2">{proj.status}</td>
              <td className="p-2">{proj.completion}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DataTable;
