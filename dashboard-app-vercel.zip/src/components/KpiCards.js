
import React from "react";

function KpiCards({ projects }) {
  const total = projects.length;
  const completed = projects.filter(p => p.status === "Biten").length;
  const ongoing = projects.filter(p => p.status === "Devam Eden").length;
  const planned = projects.filter(p => p.status === "Planlanan").length;

  const stats = [
    { title: "Toplam Proje", value: total },
    { title: "Tamamlanan %", value: total ? ((completed / total) * 100).toFixed(0) + "%" : "0%" },
    { title: "Devam Eden %", value: total ? ((ongoing / total) * 100).toFixed(0) + "%" : "0%" },
    { title: "Planlanan %", value: total ? ((planned / total) * 100).toFixed(0) + "%" : "0%" }
  ];

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">
      {stats.map((stat, index) => (
        <div key={index} className="bg-white p-4 shadow rounded-xl text-center">
          <p className="text-gray-500">{stat.title}</p>
          <h2 className="text-2xl font-bold">{stat.value}</h2>
        </div>
      ))}
    </div>
  );
}

export default KpiCards;
